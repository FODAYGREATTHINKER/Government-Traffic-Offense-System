<!DOCTYPE html>
<?php
	require_once 'session.php';
?>
<html lang = "eng">
	<head>
		<title>traffic offense</title>
		<meta charset = "UTF-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/jquery-ui.css" />
	</head>
<body>
<!--------------------HEAD---------------------->
<?php include'head.php'?>
<?php include 'sidebar.php'?>


		<div id = "sidecontent" class = "well pull-right">
			<div class = "alert alert-info">Home</div>
			<div class = "alert alert-success"><center><h3>VISION</h3></center></div>
			<h4 style = "text-indent:50px;">ultricies nis competitive Information Technology Education(ITE) graduation</h4>
			<br />
			<div class = "alert alert-success"><center><h3>MISSION</h3></center></div>
			<h4 style = "text-indent:50px;">Cltricies nisi vel augue. Curabitur u equipped with the technological knowledge and skills Sed fringilla mauris and international communities</h4>
			<br />
			<div class = "alert alert-success"><center><h3>OBJECTIVE</h3></center></div>
			<ol>
				<li>ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, </li>
				</li>tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit</li>
				 <li>vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis</li>
				 <li> faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris</li>
				 </li> sit amet nibh. Donec sodales </li>
				 </div>sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc,</li>
			</ol>
		<br /><br /><br />
		</div>
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<?php include'chicredit.php';?>
</body>	
<script src = "../js/jquery-3.1.1.js"></script>
<script src = "../js/sidebar.js"></script>
</html>