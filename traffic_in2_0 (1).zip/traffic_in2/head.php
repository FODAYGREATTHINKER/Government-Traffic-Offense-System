
<html lang = "eng">
	<head>
		<title> traffic offense system</title>
		<meta charset = "UTF-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery-ui.css" />
	</head>
<body>
<nav class = "navbar navbar-default navbar-fixed-top">
	<div class = "container-fluid"><!-- 
			<img class = "pull-left" src="images/logo1.png" width="50" height="50" alt="logo"> -->
		<a class = "navbar-brand">Traffic Offense System</a>
	<div>
</nav>