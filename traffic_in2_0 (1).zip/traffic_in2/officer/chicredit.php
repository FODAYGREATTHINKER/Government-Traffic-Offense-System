<nav class = "navbar-default" id = "footer">
		<label class = "navbar-brand pull-right">&copy; Traffic offense  system  <?php echo date('Y', strtotime('+8 HOURS'))?></label>
		<label class = "navbar-brand ">tremendouschatikobo@gmail.com ( contact me for the love of better web)</label>
	</nav>