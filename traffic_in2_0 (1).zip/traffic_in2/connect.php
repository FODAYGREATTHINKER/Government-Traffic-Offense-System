<?php
	$conn = new mysqli('localhost', 'root', '', 'drivers_endorsements') or die(mysqli_error($conn));
?>